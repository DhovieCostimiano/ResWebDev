const express = require('express');
const path = require('path');

const app = express();
const port = process.env.PORT || 5000;

// Middleware to parse incoming JSON and URL-encoded data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Set up the static folder to serve HTML, CSS, and other static files
app.use(express.static('public'));

// Route to serve the login form
app.get('/form', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Handle form submission
app.post('/formPost', (req, res) => {
    console.log('Form data:', req.body);

    // Simulated form processing
    const { username, password } = req.body;

    // Redirect to the success page after form submission
    res.redirect('/success');
});

// Route to serve the success page
app.get('/success', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'success.html'));
});

// Start the server
app.listen(port, () => {
    console.log(`Server started at http://localhost:${port}`);
});
